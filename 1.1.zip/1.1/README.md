1. write a code to generate random string
2. create Dockerfile to build image
    docker build -t amolmagdum25/log_output:1.0 .
3. push image to dockerhub (you need to have sockerhub login), use below commands
    docker login
    docker push amolmagdum25/log_output:1.0
